## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 10,
  fig.height = 10,
  warning = F
)

## ----setup--------------------------------------------------------------------
# Set global chunk obptions
knitr::opts_chunk$set(fig.width=12, fig.height=12, warning = F)

# Data 
library(openxlsx)
library(dplyr)

# Tables
library(table1)

# Plots
library(ggplot2)

# Load Metabolomics Pipeline
library(MetabolomicsPipeline)

# To upload image
library(magick)


## ----workflow, fig.height=20, fig.width=16------------------------------------
img = image_read("../Workflow.png")

image_trim(img)

## ----NormalizationAndStandardization, eval=FALSE------------------------------
#  ################################################################################
#  ##### Enter Info ###############################################################
#  ################################################################################
#  
#  # Provide a path to Metabolon .xlsx file.
#  metabolon_path <- "Data/UNAZ-0501-22VW_ DATA TABLES.xlsx"
#  
#  
#  ###############################################################################
#  ##### Load Data ###############################################################
#  ###############################################################################
#  
#  #  Load raw peak data
#  #peak_data <- read.xlsx(metabolon_path, sheet = "Peak Area Data")
#  
#  peak_data <- MetabolomicsPipeline::peak_data
#  
#  # Create MetPipe Object
#  dat <- createMetPipe(raw_peak = peak_data)
#  
#  
#  ###############################################################################
#  #### Plots Before Standardization and Normalization ###########################
#  ###############################################################################
#  # Select the first five metabolites for the box plot.
#  metabolites <- names(dat@raw_peak)[2:6]
#  
#  
#  #  Create the boxplot data
#  plot_data <- peak_data %>%
#    reshape2::melt(id.vars="PARENT_SAMPLE_NAME") %>%
#    filter(variable %in% metabolites)
#  
#  
#  # Plot the box plots for each of the five metabolites.
#  ggplot(plot_data,aes(x=variable,y=value)) +
#    geom_boxplot() +
#    theme_bw()
#  
#  
#  ###############################################################################
#  ###### Standardization and Normalization ######################################
#  ###############################################################################
#  
#  # 1 Median standardization
#  med_std <- median_standardization(peak_data = dat@raw_peak)
#  
#  # 2 Minimum Value imputation
#  impute <- min_val_impute(med_std)
#  
#  # 2 Log Transformation
#  log_trans_met <- log_transformation(impute)
#  
#  
#  ###############################################################################
#  #### Plots After Standardization and Normalization ###########################
#  ###############################################################################
#  metabolites <- names(peak_data)[2:6]
#  
#  
#  # Create the boxplot data
#  plot_data <- log_trans_met %>%
#    reshape2::melt(id.vars="PARENT_SAMPLE_NAME") %>%
#    filter(variable %in% metabolites)
#  
#  
#  #  Plot the box plots for each of the five metabolites.
#  ggplot(plot_data,aes(x=variable,y=value)) +
#    geom_boxplot() +
#    theme_bw()
#  
#  ###############################################################################
#  #### Save Data MetPipe Object #################################################
#  ###############################################################################
#  
#  dat@standardized_peak <-  log_trans_met
#  
#  #saveRDS(dat,file = "../UserData/normalized.RDS")
#  

## ----AnalysisDataCreation, echo=FALSE-----------------------------------------
################################################################################
### Load Data ##################################################################
################################################################################

# Create MetPipe Object From .xlsx
#dat <- loadMetPipeFromMetabolon(metabolon_path = "Path/To/MEtabolomics.xlsx")

# Manually create MetPipe Object
dat <- createMetPipe(raw_peak = MetabolomicsPipeline::peak_data,
                     standardized_peak = MetabolomicsPipeline::peak_data_standardized,
                     meta = MetabolomicsPipeline::meta_data,
                     chemical_annotation = MetabolomicsPipeline::Chemical_Annotation)


#### Load additional Metadata
# meta_data_additional <- read.xlsx(additional_metaPath.xlsx) 
meta_data_additional <- MetabolomicsPipeline::AdditionalMeta


# 2. Merge additional vars to the meta data
if(nrow(meta_data_additional)>0){
  
  meta_data <- meta_data_additional %>% 
    left_join(dat@meta,"PARENT_SAMPLE_NAME")
  
  # Update meta data slot
  dat@meta <- meta_data
}


################################################################################
### Enter Metadata Variables For Analysis ######################################
################################################################################
metadata_variables <- c("PARENT_SAMPLE_NAME", 
                        "GROUP_NAME", 
                        "TIME1", 
                        "Gender") 


################################################################################
### Add Analysis Data To MetPipe Object ########################################
################################################################################
# 2. Create analysis data
dat@analysis <- dat@meta %>% 
  select(all_of(metadata_variables)) %>% 
  left_join(dat@standardized_peak,"PARENT_SAMPLE_NAME") 


################################################################################
### Create Table 1 #############################################################
################################################################################
# 1. Choose the meta data variable name.
var1 = "GROUP_NAME"

var2 = "TIME1" 

# 2. Choose a single variable to stratify the table by.


# 5. Create table 1
tbl1 <- table1(~ TIME1 + GROUP_NAME| Gender 
               , data = dat@analysis) 

# 6. Display table 1
tbl1

################################################################################
### Save MetPipe Object ########################################################
################################################################################

# saveRDS(dat, file = "data/demo.Rds")

## ----ExploratoryAnalysis------------------------------------------------------
################################################################################
### Load Data ##################################################################
################################################################################

# Create MetPipe Object From .xlsx
# load("../UserData/file.rds)

# MetPipe data
demo = MetabolomicsPipeline::demo

###############################################################################
### Run PCA ###################################################################
###############################################################################

# Define PCA label from metadata
meta_var = "Gender"

# Run PCA
metabolite_pca( demo,
               meta_var = meta_var)

################################################################################
### Run Heatmaps ###############################################################
################################################################################

# Heatmap with one group
metabolite_heatmap(demo,top_mets = 50,
                   group_vars = "GROUP_NAME",
                   strat_var = NULL,
                   caption = "Heatmap Arranged By Group",
                   GROUP_NAME)


# Heatmap with two groups
metabolite_heatmap(demo,top_mets = 50,
                   group_vars = c("GROUP_NAME","TIME1"),
                   strat_var = NULL,
                   caption = "Heatmap Arranged By Group and TIME",
                   GROUP_NAME, desc(TIME1))


# Heatmap with 2 group and stratified
 metabolite_heatmap(demo,top_mets = 50,
                   group_vars = c("GROUP_NAME","TIME1"),
                   strat_var = "Gender",
                   caption = "Heatmap Arranged By Group and TIME",
                   GROUP_NAME, desc(TIME1))





## ----SubpathwayAnalysis-------------------------------------------------------
################################################################################
### Load Data  #################################################################
################################################################################

# Create MetPipe Object From .xlsx
# load("../UserData/file.rds)

# MetPipe data
demo = MetabolomicsPipeline::demo

################################################################################
## Stratified Analysis #########################################################
################################################################################

# Stratified Analysis
stratified = subpathway_analysis(demo,
                                     treat_var = "GROUP_NAME",
                                     block_var = "TIME1",
                                     strat_var = "Gender")


################################################################################
### Results Plots ##############################################################
################################################################################

# significant subpathways by model type
subpath_by_model(stratified)

# Percentage of signficant subpathways within superpathways
subpath_within_superpath(stratified)

# Metabolites within subpathway
tables <- met_within_sub(stratified, subpathway = "Partially Characterized Molecules")

### Females
tables[[1]]

### Males
tables[[2]]


## ----PairwiseAnalysis---------------------------------------------------------
################################################################################
### Load Data ##################################################################
################################################################################

demo = MetabolomicsPipeline::demo

################################################################################
#### Run Pairwise Comparisons ##################################################
################################################################################

strat_pairwise = metabolite_pairwise(demo,form = "GROUP_NAME*TIME1",strat_var = "Gender")


###############################################################################
## Create Estimate Heatmap #####################################################
################################################################################

met_est_heatmap(strat_pairwise$Female, demo@chemical_annotation)


################################################################################
## Create P-value Heatmap ######################################################
################################################################################

# Female
met_p_heatmap(strat_pairwise$Female, demo@chemical_annotation)




## ----BoxPlotsAndLinePlots-----------------------------------------------------

################################################################################
#### Load Data #################################################################
################################################################################

# Create MetPipe Object From .xlsx
# load("../UserData/file.rds)

demo = MetabolomicsPipeline::demo

################################################################################
### BoxPlots ###################################################################
################################################################################

subpathway_boxplots(demo, subpathway = "Lactoyl Amino Acid", X=TIME1,
                    groupBy = GROUP_NAME, Gender =="Female")


################################################################################
## Line plots ##################################################################
################################################################################

# Set up data
demo@analysis$TIME1 <- as.numeric(factor(demo@analysis$TIME1,
                                         levels = c("PreSymp","Onset","End")))

# Create line plots 
subpathway_lineplots(demo, subpathway = "Lactoyl Amino Acid",
                     X= TIME1,groupBy = GROUP_NAME, Gender=="Female" )



