---
title: "MetabolomicsPipeline-vignette"
author: "Joel Parker"
date: "05/31/2024"
output:
  BiocStyle::html_document:
    toc: true
    toc_depth: 2
vignette: >
  %\VignetteIndexEntry{MetabolomicsPipeline-vignette}
  %\VignetteEngine{knitr::knitr}
  %\VignetteEncoding{UTF-8}
---


## Installation

``` r
if(!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
BiocManager::install("MetabolomicsPipeline")
```






## Introduction

The purpose of the MetabolomicPipeline package is to provide additional tools to
complement the analysis done by Metabolon. In this vignette we demonstrate how 
to use MetabolomicsPipeline package for:

* Exploratory Analysis

* Subpathway Analysis

* Metabolite pairwise comparisons

* Subpathway box plots and line plots


## Data Description

In this vignette, we will use data which consists of 86 samples (42
males, 44 females), three treatment groups, and the samples were taken
at three different time points.


## Metabolon data as a SummarizedExperiment

We receive multiple datasets from Metabolon, each on a different tab of
the Metabolon Excel file. The datasets needed for the downstream
analysis are the sample metadata, chemical annotation, raw peak data and
log-transformed peak data. The table below shows the tab that each
dataset is on within the Metabolon Excel file.

| Data                      | Tab of excel file    |
|---------------------------|----------------------|
| Sample metadata           | Sample Meta Data     |
| Chemical annotation       | Chemical Annotation  |
| Raw peak data             | Peak Area Data       |
| Log-transformed peak data | Log Transformed Data |


#### Load analysis data

The MetabolomicsPipeline package provides a convenient way to load each
of these datasets together as a [SummarizedExperiment](https://bioconductor.org/packages/release/bioc/vignettes/SummarizedExperiment/inst/doc/SummarizedExperiment.html) using loadMetabolon().
However, for this vignette we are using the demo data provided with the package.
This data is accessed using MetabolomicsPipeline::demoDat. In the following chunk 
we:

1. Load the demo data


2. Create a table demostring the sample distribution



``` r
################################################################################
### Load Data ##################################################################
################################################################################

# Load Metabolon data from the Excel file
#dat <- loadMetabolon(path = "../data/Metabolon.xlsx")
data("demoDat",package = "MetabolomicsPipeline")

dat = demoDat


################################################################################
### Create Table 1 #############################################################
################################################################################
# Create table 1
tbl1 <- table1(~ GROUP_NAME + TIME1| Gender
               , data = colData(dat)) 

# Display table 1
tbl1
```

<!--html_preserve--><div class="Rtable1"><table class="Rtable1">
<thead>
<tr>
<th class='rowlabel firstrow lastrow'></th>
<th class='firstrow lastrow'><span class='stratlabel'>Female<br><span class='stratn'>(N=44)</span></span></th>
<th class='firstrow lastrow'><span class='stratlabel'>Male<br><span class='stratn'>(N=42)</span></span></th>
<th class='firstrow lastrow'><span class='stratlabel'>Overall<br><span class='stratn'>(N=86)</span></span></th>
</tr>
</thead>
<tbody>
<tr>
<td class='rowlabel firstrow'>GROUP_NAME</td>
<td class='firstrow'></td>
<td class='firstrow'></td>
<td class='firstrow'></td>
</tr>
<tr>
<td class='rowlabel'>Control</td>
<td>14 (31.8%)</td>
<td>14 (33.3%)</td>
<td>28 (32.6%)</td>
</tr>
<tr>
<td class='rowlabel'>treat1</td>
<td>15 (34.1%)</td>
<td>14 (33.3%)</td>
<td>29 (33.7%)</td>
</tr>
<tr>
<td class='rowlabel lastrow'>treat2</td>
<td class='lastrow'>15 (34.1%)</td>
<td class='lastrow'>14 (33.3%)</td>
<td class='lastrow'>29 (33.7%)</td>
</tr>
<tr>
<td class='rowlabel firstrow'>TIME1</td>
<td class='firstrow'></td>
<td class='firstrow'></td>
<td class='firstrow'></td>
</tr>
<tr>
<td class='rowlabel'>End</td>
<td>14 (31.8%)</td>
<td>15 (35.7%)</td>
<td>29 (33.7%)</td>
</tr>
<tr>
<td class='rowlabel'>Onset</td>
<td>15 (34.1%)</td>
<td>14 (33.3%)</td>
<td>29 (33.7%)</td>
</tr>
<tr>
<td class='rowlabel lastrow'>PreSymp</td>
<td class='lastrow'>15 (34.1%)</td>
<td class='lastrow'>13 (31.0%)</td>
<td class='lastrow'>28 (32.6%)</td>
</tr>
</tbody>
</table>
</div><!--/html_preserve-->

## Exploratory Analysis

In data exploration, we use several methods to help us better understand
the underlying patterns in the data without using a formal hypothesis
test. In this pipeline, we are going to focus on two methods of data
exploration:

A.) Principal component analysis

B.) Heatmaps

#### Principal Component Analysis (PCA)

In general, Principal component analysis (PCA) reduces the number of
variables in a dataset while preserving as much information from the
data as possible. At a high level, PCA is constructed such that the
first principal component (PC) accounts for the largest amount of
variance within the data. The second PC accounts for
the largest remaining variance, and so on. Additionally, each
of the PCs produced by PCA is uncorrelated with 
the other principal components. PCA can allow us to visualize sources of
variation in the data. The metabolite_pca function will enable us to specify
a sample metadata variable to label the points in the plot. The metabolite_pca 
function has three arguments:

* data: SummarizedExperiment with Metabolon experiment data.

* Assay: Name of the assay to be used for the pairwise analysis
  (default='normalized')

* meta_var: A metadata variable to color code the PCA plot by.



``` r
###############################################################################
### Run PCA ###################################################################
###############################################################################

# Define PCA label from metadata
meta_var = "Gender"

# Run PCA
pca <- metabolite_pca( dat,
               meta_var = meta_var)


# Show PCA
pca
```

![plot of chunk ExploratoryAnalysis_PCA](figure/ExploratoryAnalysis_PCA-1.png)

Suppose you notice a variable with clearly separated groups that is not a 
variable of interest. In that case, consider stratifying your downstream
analysis by the values of that variable. For example, we will stratify the 
downstream analysis by male/female in our vignette data. 

#### Heatmaps

For our heatmap, the
x-axis will be the samples, and the y-axis will be the metabolites. The
values determining the colors will be the log normalized peak values for each
metabolite in each observation. We can group the observations by the 
experimental conditions. Grouping the experimental conditions in a heatmap is 
another way of visualizing sources of variation within our data.

We can use the metabolite_heatmap function to create the heatmaps, which 
requires the following arguments. 

* data: SummarizedExperiment with Metabolon experiment data.

* top_mets: The number of metabolites to include in the heatmap. The metabolites
  are chosen based on the metabolites with the highest variability. 

* group_vars: The variables to group the samples by.
caption: The title of the heatmap.

* caption: A title for the heatmap. If strat_var is used, the title will 
  automatically include the stratum with the tile.

* Assay: Which assay data to use for the heatmap (default="normalized").

* ... : You can add additional arguments to order the samples


In the chunk below, we create a PCA plot labeled by Gender. Then, we make three
heatmaps increasing by complexity. 


``` r

################################################################################
### Run Heatmaps ###############################################################
################################################################################

# Heatmap with one group
treat_heatmap <- metabolite_heatmap(dat,top_mets = 50,
                   group_vars = "GROUP_NAME",
                   strat_var = NULL,
                   caption = "Heatmap Arranged By Group",
                   Assay = "normalized",
                   GROUP_NAME)


as.ggplot(treat_heatmap)
```

![plot of chunk ExploratoryAnalysis_heatmap](figure/ExploratoryAnalysis_heatmap-1.png)

``` r


# Heatmap with two groups
treatandtime <-  metabolite_heatmap(dat,top_mets = 50,
                   group_vars = c("GROUP_NAME","TIME1"),
                   strat_var = NULL,
                   caption = "Heatmap Arranged By Group and TIME",
                   Assay = "normalized",
                   GROUP_NAME, desc(TIME1))


as.ggplot(treatandtime)
```

![plot of chunk ExploratoryAnalysis_heatmap](figure/ExploratoryAnalysis_heatmap-2.png)

``` r


# Heatmap with 2 group and stratified
 strat_heat <- metabolite_heatmap(dat,top_mets = 50,
                   group_vars = c("GROUP_NAME","TIME1"),
                   strat_var = "Gender",
                   caption = "Heatmap Arranged By Group and TIME",
                   Assay = "normalized",
                   GROUP_NAME, desc(TIME1))

 
## Female
as.ggplot(strat_heat[[1]])
```

![plot of chunk ExploratoryAnalysis_heatmap](figure/ExploratoryAnalysis_heatmap-3.png)

``` r

# Male
as.ggplot(strat_heat[[2]])
```

![plot of chunk ExploratoryAnalysis_heatmap](figure/ExploratoryAnalysis_heatmap-4.png)

## Subpathway Analysis

In the chemical annotation file, we will see that each metabolite is
within a sub-pathway, and each subpathway is within a superpathway.
There are several metabolites within each subpathway and several
sub-pathways within each Super-pathway. We can utilize an Analysis of
variance (ANOVA) model to test for a difference in peak intensities
between the treatment groups at the metabolite level, which is already
part of the Metabolon analysis. However, since multiple metabolites are
within a subpathway, it is challenging to test if the treatment
affected the peak data at the sub-pathway level. For this, we 
utilize a combined Fisher probability test. The combined Fisher test
combines the p-values from independent tests to test the hypothesis for
an overall effect. The Combined Fisher Probability is helpful
for testing a model at the subpathway level based on the pvalues from 
the model at the metabolite level.

### Combined Fished Analysis

We will test at the subpathway level by combining the p-values for each
metabolite within the subpathway for each model. We use a combination
function given by $\tilde{X}$ which combines the pvalues, resulting in a
chi-squared test statistic.

$$
\tilde{X} = -2\sum_{i=1}^k ln(p_i)
$$
where $k$ is the number of metabolites in the subpathway. We can
get a p-value from $P(X \geq\tilde{X})$, knowing that
$\tilde{X}\sim \chi^2_{2k}$. You will notice that smaller p-values will
lead to a larger $\tilde{X}$.

##### Assumptions

Since we are first testing each metabolite utilizing ANOVA, we make the
following assumptions for each metabolite,

-   *Independence:* Each observation is independent of all other
    observations. Therefore, if you have collected multiple samples from
    the same subject then this assumption may be violated.

-   *Normality:* The metabolite log-scaled intensities follow a normal
    distribution within each of the treatment groups.

-   *Homoscedasticity:* Equal variance between treatment groups.

In addition to the assumptions in the ANOVA models at the metabolite
level, the Fisher's Combined probability places an independence
assumption between the metabolites within the subpathway. 

For more about the Combined Fisher Probability and other methods that
can address this problem, see:

Loughin, Thomas M. "A systematic comparison of methods for combining
p-values from independent tests." Computational statistics & data
analysis 47.3 (2004): 467-485.

#### Models

To test our hypothesis at the subpathway level, we first have to form
our hypothesis at the metabolite level. For each metabolite, we test
three models.

1.) Interaction: $log Peak = Treatment Group + Time + Treatment*Time$

2.) Parallel: $log Peak = Treatment Group + Time$

3.) Single: $log Peak = Treatment$

For the interaction model, we are focusing only on the interaction term
"Treatment\*Time" to test if there is a significant
interaction between our treatment and the time variable. The parallel
model is testing if the time variable is explaining a significant
amount of the metabolite variance with treatment included, and the treatment
model is testing if the treatment explains a significant proportion of the 
variance for each metabolite.  

We test at the subpathway level using the Combined Fisher Probability method to 
combine the p-values from each model for all metabolites within the subpathway. 
To run the subpathway analysis, we use the "subpathway_analysis"
function, which requires the following arguments.  


* data: SummarizedExperiment with Metabolon experiment data.

* treat_var: This is the name of the variable in the analysis data that is the 
  main variable of interest.

* block_var: This is the name of the blocking variable in the dataset. If the
  experimental design does not include a blocking variable, then the value of 
  block_var=NULL.

* strat_var: Variable to stratify the subpathway analysis by. This is set to 
  NULL by default and will not stratify the analysis unless specified.

* Assay: Name of the assay to be used for the pairwise analysis 
  (default='normalized')


#### Results Summaries

With the MetabolomicsPipeline package, we provide three different ways to
summarize the results from the subpathway analysis.

1.  Number of significant subpathways by model type (subpath_by_model)

2.  Percentage of significant subpathways within superpathways 
    (subpath_within_superpath)

3.  Metabolite model results within a specified subpathway (met_within_sub)



``` r
################################################################################
## Stratified Analysis #########################################################
################################################################################

# Stratified Analysis
stratified = subpathway_analysis(dat,
                                     treat_var = "GROUP_NAME",
                                 block_var = "TIME1",
                                 strat_var = "Gender",
                                 Assay = "normalized")
#> [1] "simpleWarning in anova.lm(int_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924625"
#> [1] "simpleWarning in anova.lm(par_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924625"
#> [1] "simpleWarning in anova.lm(treat_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924625"
#> [1] "simpleWarning in anova.lm(int_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999925396"
#> [1] "simpleWarning in anova.lm(par_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999925396"
#> [1] "simpleWarning in anova.lm(treat_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999925396"
#> [1] "simpleWarning in anova.lm(int_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 100001394"
#> [1] "simpleWarning in anova.lm(par_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 100001394"
#> [1] "simpleWarning in anova.lm(treat_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 100001394"
#> [1] "simpleWarning in anova.lm(int_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924548"
#> [1] "simpleWarning in anova.lm(par_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924548"
#> [1] "simpleWarning in anova.lm(treat_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924548"
#> [1] "simpleWarning in anova.lm(int_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924748"
#> [1] "simpleWarning in anova.lm(par_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924748"
#> [1] "simpleWarning in anova.lm(treat_mod): ANOVA F-tests on an essentially perfect fit are unreliable\n for CHEM ID 999924748"
```

``` r


################################################################################
### Results Plots ##############################################################
################################################################################

# 1. significant subpathways by model type
subpath_by_model(stratified)
```

<table class=" lightable-paper" style="font-family: Cambria; width: auto !important; margin-left: auto; margin-right: auto;">
<caption>Sigificant Pathways by Model</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Model Type </th>
   <th style="text-align:right;"> Female </th>
   <th style="text-align:right;"> Male </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Interaction </td>
   <td style="text-align:right;"> 6 </td>
   <td style="text-align:right;"> 84 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Parallel </td>
   <td style="text-align:right;"> 20 </td>
   <td style="text-align:right;"> 12 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Single </td>
   <td style="text-align:right;"> 19 </td>
   <td style="text-align:right;"> 2 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> None </td>
   <td style="text-align:right;"> 65 </td>
   <td style="text-align:right;"> 12 </td>
  </tr>
</tbody>
</table>



``` r

# 2. Percentage of signficant subpathways within superpathways
subpath_within_superpath(stratified)
```

<table class=" lightable-paper" style="font-family: Cambria; width: auto !important; margin-left: auto; margin-right: auto;">
<caption>Proportion of significant subpathways within super-pathways</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Super Pathway </th>
   <th style="text-align:left;"> Percent Significant 
 (Female) </th>
   <th style="text-align:left;"> |Percent Significant 
 (Male </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Xenobiotics </td>
   <td style="text-align:left;"> 5 / 5 (100%) </td>
   <td style="text-align:left;"> 5 / 5 (100%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Amino Acid </td>
   <td style="text-align:left;"> 13 / 16 (81.25%) </td>
   <td style="text-align:left;"> 16 / 16 (100%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Peptide </td>
   <td style="text-align:left;"> 3 / 5 (60%) </td>
   <td style="text-align:left;"> 3 / 5 (60%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Nucleotide </td>
   <td style="text-align:left;"> 3 / 8 (37.5%) </td>
   <td style="text-align:left;"> 8 / 8 (100%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Lipid </td>
   <td style="text-align:left;"> 16 / 53 (30.19%) </td>
   <td style="text-align:left;"> 46 / 53 (86.79%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Carbohydrate </td>
   <td style="text-align:left;"> 2 / 8 (25%) </td>
   <td style="text-align:left;"> 7 / 8 (87.5%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Cofactors and Vitamins </td>
   <td style="text-align:left;"> 2 / 11 (18.18%) </td>
   <td style="text-align:left;"> 9 / 11 (81.82%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Energy </td>
   <td style="text-align:left;"> 0 / 2 (0%) </td>
   <td style="text-align:left;"> 2 / 2 (100%) </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Partially Characterized Molecules </td>
   <td style="text-align:left;"> 0 / 1 (0%) </td>
   <td style="text-align:left;"> 1 / 1 (100%) </td>
  </tr>
</tbody>
</table>



``` r

# 3. Metabolites within subpathway
tables <- met_within_sub(stratified,
                         subpathway = "Partially Characterized Molecules")

### Females
tables[[1]]
```

<table class=" lightable-paper" style="font-family: Cambria; width: auto !important; margin-left: auto; margin-right: auto;">
<caption>Metabolites within Partially Characterized Molecules (Female)</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Metabolite Name </th>
   <th style="text-align:right;"> Interaction_pval P-Value </th>
   <th style="text-align:right;"> Parallel_pval P-Value </th>
   <th style="text-align:right;"> Single_pval P-Value </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> glycolate (hydroxyacetate) </td>
   <td style="text-align:right;"> 0.437 </td>
   <td style="text-align:right;"> 0.435 </td>
   <td style="text-align:right;"> 0.408 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> iminodiacetate (IDA) </td>
   <td style="text-align:right;"> 0.936 </td>
   <td style="text-align:right;"> 0.373 </td>
   <td style="text-align:right;"> 0.017 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> EDTA </td>
   <td style="text-align:right;"> 0.709 </td>
   <td style="text-align:right;"> 0.269 </td>
   <td style="text-align:right;"> 0.098 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> ectoine </td>
   <td style="text-align:right;"> 0.833 </td>
   <td style="text-align:right;"> 0.742 </td>
   <td style="text-align:right;"> 0.572 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> sulfate* </td>
   <td style="text-align:right;"> 0.596 </td>
   <td style="text-align:right;"> 0.880 </td>
   <td style="text-align:right;"> 0.858 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> ethyl glucuronide </td>
   <td style="text-align:right;"> 0.293 </td>
   <td style="text-align:right;"> 0.891 </td>
   <td style="text-align:right;"> 0.329 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> dimethyl sulfone </td>
   <td style="text-align:right;"> 0.703 </td>
   <td style="text-align:right;"> 0.350 </td>
   <td style="text-align:right;"> 0.908 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3-acetylphenol sulfate </td>
   <td style="text-align:right;"> 0.533 </td>
   <td style="text-align:right;"> 0.033 </td>
   <td style="text-align:right;"> 0.018 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> benzoylcarnitine* </td>
   <td style="text-align:right;"> 0.594 </td>
   <td style="text-align:right;"> 0.271 </td>
   <td style="text-align:right;"> 0.067 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> S-(3-hydroxypropyl)mercapturic acid (HPMA) </td>
   <td style="text-align:right;"> 0.556 </td>
   <td style="text-align:right;"> 0.346 </td>
   <td style="text-align:right;"> 0.055 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> O-sulfo-tyrosine </td>
   <td style="text-align:right;"> 0.558 </td>
   <td style="text-align:right;"> 0.632 </td>
   <td style="text-align:right;"> 0.086 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3-hydroxypyridine sulfate </td>
   <td style="text-align:right;"> 0.470 </td>
   <td style="text-align:right;"> 0.163 </td>
   <td style="text-align:right;"> 0.001 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 6-hydroxyindole sulfate </td>
   <td style="text-align:right;"> 0.266 </td>
   <td style="text-align:right;"> 0.292 </td>
   <td style="text-align:right;"> 0.051 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 1,2,3-benzenetriol sulfate (2) </td>
   <td style="text-align:right;"> 0.208 </td>
   <td style="text-align:right;"> 0.097 </td>
   <td style="text-align:right;"> 0.000 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> thioproline </td>
   <td style="text-align:right;"> 0.493 </td>
   <td style="text-align:right;"> 0.113 </td>
   <td style="text-align:right;"> 0.387 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 4-acetamidobenzoate </td>
   <td style="text-align:right;"> 0.069 </td>
   <td style="text-align:right;"> 0.026 </td>
   <td style="text-align:right;"> 0.084 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> perfluorooctanesulfonate (PFOS) </td>
   <td style="text-align:right;"> 0.397 </td>
   <td style="text-align:right;"> 0.010 </td>
   <td style="text-align:right;"> 0.199 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> methylnaphthyl sulfate (1)* </td>
   <td style="text-align:right;"> 0.443 </td>
   <td style="text-align:right;"> 0.670 </td>
   <td style="text-align:right;"> 0.065 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> methylnaphthyl sulfate (2)* </td>
   <td style="text-align:right;"> 0.648 </td>
   <td style="text-align:right;"> 0.633 </td>
   <td style="text-align:right;"> 0.002 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 2,2'-methylenebis(6-tert-butyl-p-cresol) </td>
   <td style="text-align:right;"> 0.011 </td>
   <td style="text-align:right;"> 0.000 </td>
   <td style="text-align:right;"> 0.100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3-hydroxy-2-methylpyridine sulfate </td>
   <td style="text-align:right;"> 0.392 </td>
   <td style="text-align:right;"> 0.083 </td>
   <td style="text-align:right;"> 0.001 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3,5-dichloro-2,6-dihydroxybenzoic acid </td>
   <td style="text-align:right;"> 0.442 </td>
   <td style="text-align:right;"> 0.002 </td>
   <td style="text-align:right;"> 0.253 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3-bromo-5-chloro-2,6-dihydroxybenzoic acid* </td>
   <td style="text-align:right;"> 0.613 </td>
   <td style="text-align:right;"> 0.008 </td>
   <td style="text-align:right;"> 0.208 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 4-chlorobenzoic acid </td>
   <td style="text-align:right;"> 0.364 </td>
   <td style="text-align:right;"> 0.538 </td>
   <td style="text-align:right;"> 0.664 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> perfluorohexanesulfonate (PFHxS) </td>
   <td style="text-align:right;"> 0.529 </td>
   <td style="text-align:right;"> 0.123 </td>
   <td style="text-align:right;"> 0.230 </td>
  </tr>
</tbody>
</table>



``` r

### Males
tables[[2]]
```

<table class=" lightable-paper" style="font-family: Cambria; width: auto !important; margin-left: auto; margin-right: auto;">
<caption>Metabolites within Partially Characterized Molecules (Male)</caption>
 <thead>
  <tr>
   <th style="text-align:left;"> Metabolite Name </th>
   <th style="text-align:right;"> Interaction_pval P-Value </th>
   <th style="text-align:right;"> Parallel_pval P-Value </th>
   <th style="text-align:right;"> Single_pval P-Value </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> glycolate (hydroxyacetate) </td>
   <td style="text-align:right;"> 0.054 </td>
   <td style="text-align:right;"> 0.069 </td>
   <td style="text-align:right;"> 0.181 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> iminodiacetate (IDA) </td>
   <td style="text-align:right;"> 0.052 </td>
   <td style="text-align:right;"> 0.954 </td>
   <td style="text-align:right;"> 0.001 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> EDTA </td>
   <td style="text-align:right;"> 0.116 </td>
   <td style="text-align:right;"> 0.987 </td>
   <td style="text-align:right;"> 0.005 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> ectoine </td>
   <td style="text-align:right;"> 0.492 </td>
   <td style="text-align:right;"> 0.019 </td>
   <td style="text-align:right;"> 0.284 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> sulfate* </td>
   <td style="text-align:right;"> 0.315 </td>
   <td style="text-align:right;"> 0.247 </td>
   <td style="text-align:right;"> 0.891 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> ethyl glucuronide </td>
   <td style="text-align:right;"> 0.032 </td>
   <td style="text-align:right;"> 0.114 </td>
   <td style="text-align:right;"> 0.035 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> dimethyl sulfone </td>
   <td style="text-align:right;"> 0.002 </td>
   <td style="text-align:right;"> 0.021 </td>
   <td style="text-align:right;"> 0.236 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3-acetylphenol sulfate </td>
   <td style="text-align:right;"> 0.160 </td>
   <td style="text-align:right;"> 0.566 </td>
   <td style="text-align:right;"> 0.837 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> benzoylcarnitine* </td>
   <td style="text-align:right;"> 0.378 </td>
   <td style="text-align:right;"> 0.272 </td>
   <td style="text-align:right;"> 0.055 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> S-(3-hydroxypropyl)mercapturic acid (HPMA) </td>
   <td style="text-align:right;"> 0.033 </td>
   <td style="text-align:right;"> 0.027 </td>
   <td style="text-align:right;"> 0.113 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> O-sulfo-tyrosine </td>
   <td style="text-align:right;"> 0.162 </td>
   <td style="text-align:right;"> 0.020 </td>
   <td style="text-align:right;"> 0.618 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3-hydroxypyridine sulfate </td>
   <td style="text-align:right;"> 0.095 </td>
   <td style="text-align:right;"> 0.100 </td>
   <td style="text-align:right;"> 0.161 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 6-hydroxyindole sulfate </td>
   <td style="text-align:right;"> 0.064 </td>
   <td style="text-align:right;"> 0.069 </td>
   <td style="text-align:right;"> 0.498 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 1,2,3-benzenetriol sulfate (2) </td>
   <td style="text-align:right;"> 0.293 </td>
   <td style="text-align:right;"> 0.361 </td>
   <td style="text-align:right;"> 0.458 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> thioproline </td>
   <td style="text-align:right;"> 0.004 </td>
   <td style="text-align:right;"> 0.931 </td>
   <td style="text-align:right;"> 0.371 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 4-acetamidobenzoate </td>
   <td style="text-align:right;"> 0.801 </td>
   <td style="text-align:right;"> 0.190 </td>
   <td style="text-align:right;"> 0.253 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> perfluorooctanesulfonate (PFOS) </td>
   <td style="text-align:right;"> 0.058 </td>
   <td style="text-align:right;"> 0.122 </td>
   <td style="text-align:right;"> 0.387 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> methylnaphthyl sulfate (1)* </td>
   <td style="text-align:right;"> 0.042 </td>
   <td style="text-align:right;"> 0.064 </td>
   <td style="text-align:right;"> 0.055 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> methylnaphthyl sulfate (2)* </td>
   <td style="text-align:right;"> 0.033 </td>
   <td style="text-align:right;"> 0.013 </td>
   <td style="text-align:right;"> 0.067 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 2,2'-methylenebis(6-tert-butyl-p-cresol) </td>
   <td style="text-align:right;"> 0.006 </td>
   <td style="text-align:right;"> 0.000 </td>
   <td style="text-align:right;"> 0.419 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3-hydroxy-2-methylpyridine sulfate </td>
   <td style="text-align:right;"> 0.258 </td>
   <td style="text-align:right;"> 0.095 </td>
   <td style="text-align:right;"> 0.369 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3,5-dichloro-2,6-dihydroxybenzoic acid </td>
   <td style="text-align:right;"> 0.043 </td>
   <td style="text-align:right;"> 0.002 </td>
   <td style="text-align:right;"> 0.251 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 3-bromo-5-chloro-2,6-dihydroxybenzoic acid* </td>
   <td style="text-align:right;"> 0.044 </td>
   <td style="text-align:right;"> 0.020 </td>
   <td style="text-align:right;"> 0.135 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> 4-chlorobenzoic acid </td>
   <td style="text-align:right;"> 0.933 </td>
   <td style="text-align:right;"> 0.343 </td>
   <td style="text-align:right;"> 0.617 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> perfluorohexanesulfonate (PFHxS) </td>
   <td style="text-align:right;"> 0.026 </td>
   <td style="text-align:right;"> 0.486 </td>
   <td style="text-align:right;"> 0.049 </td>
  </tr>
</tbody>
</table>



## Pairwise Analysis

We can look at the pairwise comparisons for all
experimental groups at the metabolite level. Metabolon includes this as part of 
their analysis. However, if you need to change the model, you must rerun the
pairwise analysis. We will use the metabolite_pairwise function within the
MetabolomicsPipeline package, which requires the following arguments: 


* data: SummarizedExperiment with Metabolon experiment data.

* Assay: Name of the assay to be used for the pairwise analysis 
  (default='normalized')

* mets: Chemical ID for the metabolites of interest. If NULL then the pairwise
  analysis is completed for all metabololites.

* form: This is a character string the resembles the right hand side of a simple
  linear regression model in R. For example form = "Group1 + Group2".

* strat_var: A variable in the analysis data to stratify the model by. If this 
  is specified, a list of results will be returned.

#### Log Fold-Change Heatmap

We will produce a heatmap of the log fold changes for the metabolites with a 
significant overall p-value (which tested if the treatment group means were 
equal under the null hypothesis). The
heatmap colors will only show if the log fold-change is greater than
log(2) or less than log(.5). Therefore, this heatmap will only focus on
comparisons with a fold change of two or greater. The met_est_heatmap function 
will produce an interactive heatmap using the results from the pairwise analysis.  

#### P-Value Heatmap

Similar to the pairwise estimate heatmap, we will produce a heatmap where the 
heatmap will only include metabolites with a significant overall p-value, and 
the values in the heat map will only be colored if the pairwise comparison is 
significant. We use the met_p_heatmap function to create an interactive p-value
heatmap. 








