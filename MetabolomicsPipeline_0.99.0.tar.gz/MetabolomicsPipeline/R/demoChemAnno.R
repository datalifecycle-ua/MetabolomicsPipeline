#' Demo Chemical Annotation Data
#'
#' A small example of chemical annotation data for the MetabolomicsPipeline package.
#'
#' @name demoChemAnno
#' @format A data frame with annotation for 1102 metabolites
#' @source Generated for demonstration

"demoChemAnno"
